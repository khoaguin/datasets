This dataset contains over 50000 images in 6 classes, splitted for train, test and val pics. It's like a 'hello world' in start of machine learning in medicine based on https://www.kaggle.com/datasets/andrewmvd/medical-mnist..

Link to kaggle: https://www.kaggle.com/datasets/gennadiimanzhos/medical-mnist-train-test-val
